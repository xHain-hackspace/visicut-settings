# Visicut-Settings-xHain-Makespace-Berlin

This repository contains the VisiCut laser cutter settings for the xHain Hack+Makespace  Berlin.  

Laser Cutter: Epilog ZING 30W
